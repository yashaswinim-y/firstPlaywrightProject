import { Page,expect } from "@playwright/test";
import { Helper } from "./PageManager/helper";

export class DashBoardPage extends Helper {
    constructor(page: Page) {
        super(page)
    }

    async verifyDashboardMessage()
    {
        await expect(await this.page.locator(".oxd-topbar-header-breadcrumb-module")).toContainText("Dashboard")
    }

    async bufferUserName()
    {
        const loggedInUser=await this.page.locator(".oxd-userdropdown-name").textContent()
    }

    async clickOnLeave()
    {
        await this.page.locator(".oxd-sidepanel-body ul li a").nth(2).click()
    }
}