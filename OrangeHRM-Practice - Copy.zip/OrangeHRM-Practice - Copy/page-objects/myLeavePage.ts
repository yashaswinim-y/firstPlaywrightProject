import { Page, expect } from "@playwright/test";
import { Helper } from "./PageManager/helper";

export class MyLeavePage extends Helper {
    constructor(page: Page) {
        super(page)
    }

    async clickOnMyLeave() {
        await this.page.locator(".oxd-topbar-body-nav-tab-item").filter({ hasText: "My Leave" }).click()
    }

    /**
     * 
     * @param option - to click on search option, pass argument as "yes". 
     * else to select "reset" btn pass argument as "no"
     */
    async searchAppliedLeave(option: string) {
        if (option == "Search") {
            await this.page.getByRole('button', { name: "Search" }).click()
        }
        else {
            await this.page.getByRole('button', { name: "Reset" }).click()
        }
    }

    async clickOnCancelLeave() {
        const chckBox=await this.page.locator(".oxd-icon.bi-check.oxd-checkbox-input-icon").last()
        await chckBox.scrollIntoViewIfNeeded()
        await chckBox.click()
        await this.page.getByRole('button',{name:"Cancel"}).first().click()
    }

    async unselectCancelledLeaveStatus() {
        await this.waitForNumberOfSeconds(1)
        const status= await this.page.locator(".oxd-chip.oxd-multiselect-chips-selected .oxd-icon.bi-x.--clear").count()
        for(let i=status-1;i>=0;i--)
        {
            await this.page.locator(".oxd-chip.oxd-multiselect-chips-selected .oxd-icon.bi-x.--clear").nth(i).click()
           await this.waitForNumberOfSeconds(1)
        }
        await this.waitForNumberOfSeconds(1)
    }

    async selectLeaveWithStatusOption(leaveStatus:string) {
        await this.waitForNumberOfSeconds(1)
        await this.page.locator(".oxd-select-text-input").first().click()
        await this.page.locator(".oxd-multiselect-wrapper [role='listbox']",{hasText:`${leaveStatus}`}).click()
        await this.waitForNumberOfSeconds(1)
    }

    /**
     * 
     * @param confirm - arguments are => confirm and cancel
     *  if argument is confirm-it will clicks on confirm option
     * else if arugument is 'cancel', it will click on cancel option
     */
    async leaveCancelConfirmPopup(confirm:string)
    {
        if(confirm=="confirm")
        {
            await this.page.locator(".orangehrm-modal-footer .oxd-button--secondary").click() 
        }
        else
        {
            await this.page.locator(".oxd-button--text.orangehrm-button-margin").click()
        }
        await expect(await this.page.locator(".orangehrm-header-container")).toContainText("No Records Found")
        
    }
}
