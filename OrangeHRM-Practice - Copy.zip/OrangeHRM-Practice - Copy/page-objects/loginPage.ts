import { Page,expect } from "@playwright/test";
import { Helper } from "./PageManager/helper";

export class LoginPage extends Helper {
     
    constructor(page: Page) {
        super(page)
    }

    async verifyTheHomePageTitle()
    {
        await expect(this.page).toHaveTitle(/OrangeHRM/);
    }

    async bufferUsernameAndPassword()
    {
        const credentials=await this.page.locator(".orangehrm-login-error div p")
        const user_name=credentials.first().innerText()
        const splittedUserValue=(await user_name).split(":")
        const user=splittedUserValue[1]
      
        const user_password=credentials.last().innerText()
        const splittedPasswordValue=(await user_password).split(":")
        const password=splittedPasswordValue[1]
    }

    async loginWithCredentials(user:string,password:string,signInBtn:string)
    {
        await this.bufferUsernameAndPassword()
        await this.page.getByRole("textbox",{name:"Username"}).pressSequentially(user)
        await this.page.getByRole("textbox",{name:"Password"}).pressSequentially(password)
        if(signInBtn=="yes")
        {
            await this.page.locator('.orangehrm-login-button').click()
        }
    }
}