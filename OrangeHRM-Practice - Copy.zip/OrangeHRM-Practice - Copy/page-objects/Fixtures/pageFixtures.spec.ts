import { test as base } from '@playwright/test'
import { LoginPage } from '../loginPage'
import { DashBoardPage } from '../dashBoardPage'
import { ApplyLeavePage } from '../applyLeavePage'
import { MyLeavePage } from '../myLeavePage'

export type testoptions = {
    loginPage: LoginPage
    dashboard: DashBoardPage
    applyLeavePage: ApplyLeavePage
    myLeavePage: MyLeavePage
    workerStorageState
}

const testFixture = base.extend<testoptions>({

    loginPage: async ({ page }, use) => {
        const login = new LoginPage(page)
        await use(login)
    },
    dashboard: async ({ page }, use) => {
        const db = new DashBoardPage(page)
        await use(db)
    },
    applyLeavePage: async ({ page }, use) => {
        const applyLeave = new ApplyLeavePage(page)
        await use(applyLeave)
    },
    myLeavePage: async ({ page }, use) => {
        const myLeave = new MyLeavePage(page)
        await use(myLeave)
    },
})

export const test = testFixture;