import { Page, expect } from "@playwright/test";
import { Helper } from "./PageManager/helper";

export class ApplyLeavePage extends Helper {
    constructor(page: Page) {
        super(page)
    }

    async clickOnApplyLeave() {
        await this.page.locator(".oxd-topbar-body-nav-tab-item").filter({ hasText: "Apply" }).click()
    }

    async clickOnLeaveTypeDropdownAndSelectType() {
        await this.page.locator(".oxd-select-text-input").click()
        await this.waitForNumberOfSeconds(1)
        await this.page.locator(".oxd-select-dropdown.--positon-bottom div").last().click()
    }

    async skip(numberOfDays: number, months: number) {
        await this.page.locator(".oxd-icon.bi-calendar.oxd-date-input-icon").first().click()
        let date = new Date()
        date.setDate(date.getDate() + numberOfDays)
        const expectedDate = date.getDate().toString()
        console.log(expectedDate) //29
        const monthLong = (date.toLocaleString('EN-US', { month: 'long' }) + 1)
        console.log(monthLong.toString())//August  
        const b = date.setDate(date.getMonth() + 1)
        console.log(b)
        const year = date.getFullYear()
        console.log(year)  //2024
        let CalenderMonth = await this.page.locator(".oxd-calendar-selector-month-selected").textContent()
        let CalenderYear = await this.page.locator(".oxd-calendar-selector-year-selected").textContent()
        let calenderMonthYear = `${CalenderMonth}${months} ${CalenderYear}`
        let expectedMonthYear = `${monthLong} ${year}`
        console.log(expectedMonthYear)  //August 2024
        console.log(calenderMonthYear)  //August 2024
        while (!calenderMonthYear?.includes(expectedMonthYear))//(August 2024 != August 2024)
        {
            await this.page.locator(".oxd-icon.bi-chevron-right").click() //selecting right arrow
            const calenderYearArrow = await this.page.locator(".oxd-input.oxd-input--focus").textContent() //2024 arrow
            console.log(calenderYearArrow)
        }
        await this.page.locator(".oxd-calendar-dates-grid").getByText(expectedDate, { exact: true }).click()
    }

    async selectToDate(noOfDays: number, month: string) {
        await this.waitForNumberOfSeconds(1)
        let months = ["January", "Febrauary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
        await this.page.locator(".oxd-icon.bi-calendar.oxd-date-input-icon").last().click()
        let date = new Date()
        date.setDate(noOfDays)
        const expectedDate = date.getDate().toString()
        await this.waitForNumberOfSeconds(1)
        let CalenderMonth = await this.page.locator(".oxd-calendar-selector-month-selected").textContent()
        if (month == CalenderMonth)  //(aug==aug)
        {
            await this.page.locator(".oxd-calendar-dates-grid").getByText(expectedDate, { exact: true }).click()
        }
        else {
            await this.page.locator(".oxd-calendar-selector-month-selected").click()
            await this.page.locator(".oxd-calendar-dropdown li", { hasText: `${month}` }).click()
            await this.page.locator(".oxd-calendar-dates-grid").getByText(expectedDate, { exact: true }).click()
        }
    }

    async selectFromDate(noOfDays: number, month: string) {
        let months = ["January", "Febrauary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
        await this.page.locator(".oxd-icon.bi-calendar.oxd-date-input-icon").first().click()
        let date = new Date()
        date.setDate(date.getDate() + noOfDays)
        const expectedDate = date.getDate().toString()

        let CalenderMonth = await this.page.locator(".oxd-calendar-selector-month-selected").textContent()
        if (month == CalenderMonth)  //(aug==aug)
        {
            await this.page.locator(".oxd-calendar-dates-grid").getByText(expectedDate, { exact: true }).click()
        }
        else {
            await this.page.locator(".oxd-calendar-selector-month-selected").click()
            await this.page.locator(".oxd-calendar-dropdown li", { hasText: `${month}` }).click()
            await this.page.locator(".oxd-calendar-dates-grid").getByText(expectedDate, { exact: true }).click()
        }
    }

    /**
     * 
     * @param leaveType Represents -> 
     * 0 - All Days, 
     * 1 - Start Day Only,
     * 2 - End Day Only, and 3 - Start and End Day
     */
    async selectLeaveType(leaveType: number) {
        await this.waitForNumberOfSeconds(1)
        let partialDays = ["All Days", "Start Day Only", "End Day Only", "Start and End Day"]
        await this.page.locator(".oxd-select-text-input").last().click()
        await this.page.locator(".oxd-select-option", { hasText: `${partialDays[leaveType]}` }).click()
    }

    async selectDurationType(durationType: string) {
        await this.waitForNumberOfSeconds(1)
        await this.page.locator(".oxd-select-text-input").last().click()
        // await this.page.locator(".oxd-select-option").nth(durationType).click()
        await this.page.locator(".oxd-select-option",{hasText:`${durationType}`}).click()
    }

    async addComments() {
        await this.page.locator('.oxd-textarea.oxd-textarea--active').fill("hbhjhb")
    }

    async clickOnApply() {
        await this.page.getByRole('button', { name: "Apply" }).click()
        await this.waitForNumberOfSeconds(5)
    }
}
