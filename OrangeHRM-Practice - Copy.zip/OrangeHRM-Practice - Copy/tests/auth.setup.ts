import { test as setup } from '../page-objects/Fixtures/pageFixtures.spec'
import { expect } from '@playwright/test';
import * as data from '../test-data/testData.json'

const authFile = '.auth/user.json';

setup('authenticate', async ({ page, loginPage}) => {
  await page.goto('');
  await loginPage.verifyTheHomePageTitle()
  await loginPage.loginWithCredentials(data.user,data.password,"yes")
  await page.waitForURL('https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index');
  await page.context().storageState({ path: authFile });
});