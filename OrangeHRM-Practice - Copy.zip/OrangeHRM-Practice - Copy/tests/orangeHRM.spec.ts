import {expect } from '@playwright/test';
import {test} from '../page-objects/Fixtures/pageFixtures.spec'
import * as data from '../test-data/testData.json'

test.beforeEach('launch OrangeHRM Application and Login', async ({ page }) => {
  test.slow()
  await page.goto('');
});

test('Apply Leave', async ({dashboard,applyLeavePage}) => {
  await dashboard.verifyDashboardMessage()
  await dashboard.bufferUserName()
  await dashboard.clickOnLeave()
  await applyLeavePage.clickOnApplyLeave()
  await applyLeavePage.clickOnLeaveTypeDropdownAndSelectType()
  await applyLeavePage.selectFromDate(data.fromDate,data.startMonth)
  await applyLeavePage.selectToDate(data.toDate,data.endMonth)
  await applyLeavePage.selectLeaveType(0)
  await applyLeavePage.selectDurationType(data.durationType)
  await applyLeavePage.addComments()
  await applyLeavePage.clickOnApply()
})

test('Verify Applied Leave in MyLeave Section', async ({dashboard,applyLeavePage,myLeavePage}) => {
  await dashboard.clickOnLeave()
  await myLeavePage.clickOnMyLeave()
  await applyLeavePage.selectFromDate(data.fromDate,data.startMonth)
  await applyLeavePage.selectToDate(data.toDate,data.endMonth)
  await myLeavePage.unselectCancelledLeaveStatus()
  await myLeavePage.selectLeaveWithStatusOption(data['leave-status'])
  await myLeavePage.searchAppliedLeave("Search")
  await myLeavePage.clickOnCancelLeave()
  await myLeavePage.leaveCancelConfirmPopup("confirm")
})

test.afterAll(async({browser})=>
{
  await browser.close()
})